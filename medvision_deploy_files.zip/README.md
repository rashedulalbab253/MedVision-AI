# MedVision AI

Educational chest X-ray computer-vision research demo built with PyTorch, ResNet-18, Grad-CAM, and Streamlit.

## Required repository structure

```text
medvision-xray/
├── app.py
├── requirements.txt
├── .gitignore
├── .streamlit/
│   └── config.toml
└── models/
    ├── best_model.pt
    └── roc_curve.png
```

Do not upload the `.venv` folder or the NIH dataset to GitHub.

## Run locally

```powershell
python -m streamlit run app.py
```

## Deploy

1. Push this repository to GitHub.
2. Sign in to Streamlit Community Cloud.
3. Choose **Create app**.
4. Select the GitHub repository and branch.
5. Set the entrypoint to `app.py`.
6. In Advanced settings, choose Python 3.12.
7. Deploy.
